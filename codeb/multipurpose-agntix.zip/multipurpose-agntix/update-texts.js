// Website Text Update System
// This script automatically updates website texts from JSON data

(function() {
    'use strict';

    // Check if there's saved text data in localStorage
    async function checkForUpdates() {
        // 먼저 localStorage 확인
        const savedTexts = localStorage.getItem('websiteTexts');
        const lastUpdate = localStorage.getItem('websiteTextsTimestamp');
        
        if (savedTexts) {
            try {
                const data = JSON.parse(savedTexts);
                console.log('Found saved text data from:', new Date(lastUpdate).toLocaleString('ko-KR'));
                applyTextUpdates(data);
                return;
            } catch (error) {
                console.error('Error parsing saved texts:', error);
            }
        }
        
        // localStorage에 없으면 JSON 파일 로드
        try {
            const response = await fetch('website-texts-updated.json');
            if (response.ok) {
                const data = await response.json();
                console.log('Loaded text data from JSON file');
                applyTextUpdates(data);
                // localStorage에도 저장
                localStorage.setItem('websiteTexts', JSON.stringify(data));
                localStorage.setItem('websiteTextsTimestamp', new Date().toISOString());
            }
        } catch (error) {
            console.error('Error loading JSON file:', error);
        }
    }

    // Apply text updates to the page
    function applyTextUpdates(data) {
        let updateCount = 0;
        
        // website_texts 객체가 있는지 확인
        const texts = data.website_texts || data;
        
        // Get current page name
        const currentPage = window.location.pathname.split('/').pop() || 'index.html';
        console.log('Current page:', currentPage);

        // Navigation menu updates
        if (texts.menu?.main_navigation) {
            // Main navigation in header
            document.querySelectorAll('.tp-mobile-menu-active > ul > li > a').forEach(link => {
                const text = link.textContent.trim();
                texts.menu.main_navigation.forEach(item => {
                    if (item.english === text && item.korean) {
                        link.textContent = item.korean;
                        updateCount++;
                    }
                });
            });

            // Language selector
            if (texts.menu.language_selector) {
                document.querySelectorAll('.tp-header-lang-list a').forEach(link => {
                    const text = link.textContent.trim();
                    texts.menu.language_selector.forEach(item => {
                        if (item.english === text && item.korean) {
                            link.textContent = item.korean;
                            updateCount++;
                        }
                    });
                });
            }

            // CTA button
            if (texts.menu.cta_button?.korean) {
                const ctaBtn = document.querySelector('.tp-header-btn-text');
                if (ctaBtn) {
                    ctaBtn.textContent = texts.menu.cta_button.korean;
                    updateCount++;
                }
            }
        }

        // Page-specific updates based on current page
        if (currentPage === 'index.html' || currentPage === '') {
            updateCount = updateHomePage(texts, updateCount);
        } else if (currentPage === 'about-creative-dark.html') {
            updateCount = updateAboutPage(texts, updateCount);
        } else if (currentPage === 'service-4-dark.html') {
            updateCount = updateServicePage(texts, updateCount);
        } else if (currentPage === 'portfolio-creative-skew-slider.html') {
            updateCount = updatePortfolioPage(texts, updateCount);
        } else if (currentPage === 'faq-dark.html') {
            updateCount = updateFAQPage(texts, updateCount);
        } else if (currentPage === 'contact-us-dark.html') {
            updateCount = updateContactPage(texts, updateCount);
        }

        console.log(`Updated ${updateCount} text elements`);
        
        // 디버깅을 위해 찾지 못한 요소들 로그
        console.log('Debugging info:');
        console.log('Current page:', currentPage);
        console.log('Found navigation items:', document.querySelectorAll('.tp-mobile-menu-active > ul > li > a').length);
        console.log('Found hero title:', document.querySelector('.tp-hero-title'));
        console.log('Found about subtitle:', document.querySelector('.tp-section-title-pre'));
    }

    // Update Home Page
    function updateHomePage(texts, updateCount) {
        // Hero section
        if (texts.hero_section) {
            // Title
            if (texts.hero_section.title?.korean) {
                const heroTitle = document.querySelector('.tp-hero-title');
                if (heroTitle) {
                    const titleParts = texts.hero_section.title.korean.split(' ');
                    if (titleParts.length >= 3) {
                        heroTitle.innerHTML = `
                            <span>${titleParts[0]}</span> <br>
                            <span><img class="tp-hero-video d-none d-xl-inline-block" src="assets/img/home-01/hero/hero-video-1.jpg" alt="">${titleParts[1]}</span> ${titleParts.slice(2).join(' ')}
                        `;
                    } else {
                        heroTitle.innerHTML = texts.hero_section.title.korean;
                    }
                    updateCount++;
                }
            }

            // Subtitle
            if (texts.hero_section.subtitle?.korean) {
                const heroInfo = document.querySelector('.tp-hero-info p');
                if (heroInfo) {
                    heroInfo.innerHTML = texts.hero_section.subtitle.korean;
                    updateCount++;
                }
            }

            // Testimonial
            if (texts.hero_section.testimonial?.text?.korean) {
                const testimonialText = document.querySelector('.tp-testimonial-text p');
                if (testimonialText) {
                    testimonialText.textContent = texts.hero_section.testimonial.text.korean;
                    updateCount++;
                }
            }

            if (texts.hero_section.testimonial?.link_text?.korean) {
                const moreLink = document.querySelector('.tp-testimonial-text a');
                if (moreLink) {
                    moreLink.textContent = texts.hero_section.testimonial.link_text.korean;
                    updateCount++;
                }
            }
        }

        // About section
        if (texts.about_section) {
            // Subtitle
            if (texts.about_section.subtitle?.korean) {
                const aboutSubtitle = document.querySelector('.tp-section-title-pre');
                if (aboutSubtitle && aboutSubtitle.textContent.includes('WHO WE ARE')) {
                    aboutSubtitle.textContent = texts.about_section.subtitle.korean;
                    updateCount++;
                }
            }

            // Main text
            if (texts.about_section.main_text?.korean) {
                const aboutTitle = document.querySelector('.tp-about-2-title');
                if (aboutTitle) {
                    aboutTitle.innerHTML = texts.about_section.main_text.korean;
                    updateCount++;
                }
            }

            // Highlight text
            if (texts.about_section.highlight_text?.korean) {
                const highlightText = document.querySelector('.tp-about-2-text p');
                if (highlightText) {
                    highlightText.textContent = texts.about_section.highlight_text.korean;
                    updateCount++;
                }
            }

            // Stats
            if (texts.about_section.stats) {
                texts.about_section.stats.forEach((stat, index) => {
                    if (stat.text?.korean) {
                        const statText = document.querySelectorAll('.tp-about-2-list-text')[index];
                        if (statText) {
                            statText.textContent = stat.text.korean;
                            updateCount++;
                        }
                    }
                });
            }
        }

        // Services section
        if (texts.services_section?.services) {
            texts.services_section.services.forEach((service, index) => {
                // Service title
                if (service.title?.korean) {
                    const serviceTitle = document.querySelectorAll('.tp-service-title')[index];
                    if (serviceTitle) {
                        serviceTitle.textContent = service.title.korean;
                        updateCount++;
                    }
                }

                // Service description
                if (service.description?.korean) {
                    const serviceDesc = document.querySelectorAll('.tp-service-content p')[index];
                    if (serviceDesc) {
                        serviceDesc.textContent = service.description.korean;
                        updateCount++;
                    }
                }

                // CTA button
                if (service.cta?.korean) {
                    const serviceCTA = document.querySelectorAll('.tp-service-btn-text')[index];
                    if (serviceCTA) {
                        serviceCTA.textContent = service.cta.korean;
                        updateCount++;
                    }
                }
            });
        }

        // Projects section
        if (texts.projects_section) {
            // Title
            if (texts.projects_section.title?.korean) {
                const projectTitle = document.querySelector('.tp-project-title-pre');
                if (projectTitle && projectTitle.textContent.includes('Featured Projects')) {
                    projectTitle.textContent = texts.projects_section.title.korean;
                    updateCount++;
                }
            }

            // CTA
            if (texts.projects_section.cta?.korean) {
                const projectCTA = document.querySelector('.tp-project-btn');
                if (projectCTA) {
                    projectCTA.textContent = texts.projects_section.cta.korean;
                    updateCount++;
                }
            }
        }

        // Footer section
        updateCount = updateFooter(texts, updateCount);
        return updateCount;
    }

    // Update About Page
    function updateAboutPage(texts, updateCount) {
        if (texts.about_page) {
            // Hero section
            if (texts.about_page.hero) {
                const aboutText = document.querySelector('.tp-about-creative-pre');
                if (aboutText && texts.about_page.hero.about_text?.korean) {
                    aboutText.textContent = texts.about_page.hero.about_text.korean;
                    updateCount++;
                }

                const introText = document.querySelector('.tp-about-creative-pre-2');
                if (introText && texts.about_page.hero.intro_text?.korean) {
                    introText.textContent = texts.about_page.hero.intro_text.korean;
                    updateCount++;
                }

                const subtitle = document.querySelector('.tp-about-creative-subtitle');
                if (subtitle && texts.about_page.hero.subtitle?.korean) {
                    subtitle.textContent = texts.about_page.hero.subtitle.korean;
                    updateCount++;
                }

                const title = document.querySelector('.tp-about-creative-title');
                if (title && texts.about_page.hero.title?.korean) {
                    title.textContent = texts.about_page.hero.title.korean;
                    updateCount++;
                }
            }

            // Content section
            if (texts.about_page.content) {
                const sectionSubtitle = document.querySelector('.tp-section-title-pre');
                if (sectionSubtitle && texts.about_page.content.section_subtitle?.korean) {
                    sectionSubtitle.textContent = texts.about_page.content.section_subtitle.korean;
                    updateCount++;
                }

                const mainTitle = document.querySelector('.tp-about-creative-section-title');
                if (mainTitle && texts.about_page.content.main_title?.korean) {
                    mainTitle.textContent = texts.about_page.content.main_title.korean;
                    updateCount++;
                }

                const ctaBtn = document.querySelector('.tp-btn-border-white');
                if (ctaBtn && texts.about_page.content.cta_button?.korean) {
                    ctaBtn.textContent = texts.about_page.content.cta_button.korean;
                    updateCount++;
                }
            }

            // Team section
            if (texts.about_page.team?.title?.korean) {
                const teamTitle = document.querySelector('h3.tp-section-title');
                if (teamTitle && teamTitle.textContent.includes('Our Team Member')) {
                    teamTitle.textContent = texts.about_page.team.title.korean;
                    updateCount++;
                }
            }

            // Update team member positions
            document.querySelectorAll('.tp-team-5-designation').forEach(designation => {
                if (designation.textContent.trim() === 'Developer' && texts.about_page.team) {
                    designation.textContent = '개발자';
                    updateCount++;
                }
            });
        }

        updateFooter(texts, updateCount);
        return updateCount;
    }

    // Update Service Page
    function updateServicePage(texts, updateCount) {
        if (texts.service_page) {
            // Hero section
            if (texts.service_page.hero) {
                const heroTitle = document.querySelector('.tp-breadcrumb-title');
                if (heroTitle && texts.service_page.hero.title?.korean) {
                    heroTitle.textContent = texts.service_page.hero.title.korean;
                    updateCount++;
                }

                const heroDesc = document.querySelector('.tp-breadcrumb-list + p');
                if (heroDesc && texts.service_page.hero.description?.korean) {
                    heroDesc.textContent = texts.service_page.hero.description.korean;
                    updateCount++;
                }
            }

            // Smart solutions section
            if (texts.service_page.smart_solutions) {
                const sectionPre = document.querySelector('.tp-section-title-pre');
                if (sectionPre && texts.service_page.smart_solutions.subtitle?.korean) {
                    sectionPre.textContent = texts.service_page.smart_solutions.subtitle.korean;
                    updateCount++;
                }

                const sectionTitle = document.querySelector('.tp-section-3-title');
                if (sectionTitle && texts.service_page.smart_solutions.title?.korean) {
                    sectionTitle.textContent = texts.service_page.smart_solutions.title.korean;
                    updateCount++;
                }

                // Service cards
                if (texts.service_page.smart_solutions.services) {
                    texts.service_page.smart_solutions.services.forEach((service, index) => {
                        const cardTitle = document.querySelectorAll('.tp-service-4-title')[index];
                        if (cardTitle && service.title?.korean) {
                            cardTitle.textContent = service.title.korean;
                            updateCount++;
                        }

                        const cardDesc = document.querySelectorAll('.tp-service-4-content p')[index];
                        if (cardDesc && service.description?.korean) {
                            cardDesc.textContent = service.description.korean;
                            updateCount++;
                        }
                    });
                }
            }

            // Pricing section
            if (texts.service_page.pricing?.plans) {
                texts.service_page.pricing.plans.forEach((plan, index) => {
                    const planTitle = document.querySelectorAll('.tp-price-3-title')[index];
                    if (planTitle && plan.title?.korean) {
                        planTitle.textContent = plan.title.korean;
                        updateCount++;
                    }

                    const planCTA = document.querySelectorAll('.tp-price-3-btn')[index];
                    if (planCTA && plan.cta?.korean) {
                        planCTA.textContent = plan.cta.korean;
                        updateCount++;
                    }
                });
            }
        }

        updateFooter(texts, updateCount);
        return updateCount;
    }

    // Update Portfolio Page
    function updatePortfolioPage(texts, updateCount) {
        if (texts.portfolio_page) {
            // Header menu button
            if (texts.portfolio_page.header?.menu_button?.korean) {
                const menuBtn = document.querySelector('.tp-header-8-bar span');
                if (menuBtn) {
                    menuBtn.textContent = texts.portfolio_page.header.menu_button.korean;
                    updateCount++;
                }
            }

            // Offcanvas
            if (texts.portfolio_page.offcanvas) {
                const closeBtn = document.querySelector('.tp-offcanvas-2-close-btn .text span');
                if (closeBtn && texts.portfolio_page.offcanvas.close_button?.korean) {
                    closeBtn.textContent = texts.portfolio_page.offcanvas.close_button.korean;
                    updateCount++;
                }

                const contactTitle = document.querySelector('.tp-offcanvas-2-right-info-title');
                if (contactTitle && texts.portfolio_page.offcanvas.contact_title?.korean) {
                    contactTitle.textContent = texts.portfolio_page.offcanvas.contact_title.korean;
                    updateCount++;
                }

                // Labels
                document.querySelectorAll('.tp-offcanvas-2-right-info-item label').forEach(label => {
                    const text = label.textContent.trim();
                    if (texts.portfolio_page.offcanvas.phone_label?.korean && text === 'Phone') {
                        label.textContent = texts.portfolio_page.offcanvas.phone_label.korean;
                        updateCount++;
                    } else if (texts.portfolio_page.offcanvas.email_label?.korean && text === 'Email') {
                        label.textContent = texts.portfolio_page.offcanvas.email_label.korean;
                        updateCount++;
                    } else if (texts.portfolio_page.offcanvas.address_label?.korean && text === 'Address') {
                        label.textContent = texts.portfolio_page.offcanvas.address_label.korean;
                        updateCount++;
                    } else if (texts.portfolio_page.offcanvas.follow_label?.korean && text === 'Follow us') {
                        label.textContent = texts.portfolio_page.offcanvas.follow_label.korean;
                        updateCount++;
                    }
                });
            }

            // Projects
            if (texts.portfolio_page.projects) {
                texts.portfolio_page.projects.forEach((project, index) => {
                    const projectTitle = document.querySelectorAll('.tp-creative-skew-title a')[index];
                    if (projectTitle && project.title?.korean) {
                        projectTitle.textContent = project.title.korean;
                        updateCount++;
                    }
                });
            }

            // Navigation
            if (texts.portfolio_page.navigation) {
                const prevBtn = document.querySelector('.tp-creative-skew-prev span');
                if (prevBtn && texts.portfolio_page.navigation.prev?.korean) {
                    prevBtn.textContent = texts.portfolio_page.navigation.prev.korean;
                    updateCount++;
                }

                const nextBtn = document.querySelector('.tp-creative-skew-next span');
                if (nextBtn && texts.portfolio_page.navigation.next?.korean) {
                    nextBtn.textContent = texts.portfolio_page.navigation.next.korean;
                    updateCount++;
                }
            }

            // Copyright
            if (texts.portfolio_page.copyright) {
                const copyrightQuestion = document.querySelector('.tp-creative-skew-copyright h5');
                if (copyrightQuestion && texts.portfolio_page.copyright.question?.korean) {
                    copyrightQuestion.textContent = texts.portfolio_page.copyright.question.korean;
                    updateCount++;
                }

                const copyrightLink = document.querySelector('.tp-creative-skew-copyright a');
                if (copyrightLink && texts.portfolio_page.copyright.cta?.korean) {
                    copyrightLink.textContent = texts.portfolio_page.copyright.cta.korean;
                    updateCount++;
                }
            }
        }
    }

    // Update FAQ Page
    function updateFAQPage(texts, updateCount) {
        if (texts.faq_page) {
            // Hero section
            if (texts.faq_page.hero) {
                const heroTitle = document.querySelector('.tp-breadcrumb-title');
                if (heroTitle && texts.faq_page.hero.title?.korean) {
                    heroTitle.textContent = texts.faq_page.hero.title.korean;
                    updateCount++;
                }

                const heroDesc = document.querySelector('.tp-breadcrumb-list + p');
                if (heroDesc && texts.faq_page.hero.description?.korean) {
                    heroDesc.textContent = texts.faq_page.hero.description.korean;
                    updateCount++;
                }

                // Breadcrumb
                const breadcrumbLink = document.querySelector('.tp-breadcrumb-list-item:last-child');
                if (breadcrumbLink && texts.faq_page.hero.breadcrumb?.korean) {
                    breadcrumbLink.textContent = texts.faq_page.hero.breadcrumb.korean;
                    updateCount++;
                }
            }

            // FAQ items
            if (texts.faq_page.questions) {
                texts.faq_page.questions.forEach((faq, index) => {
                    const questionBtn = document.querySelectorAll('.accordion-button')[index];
                    if (questionBtn && faq.question?.korean) {
                        questionBtn.textContent = faq.question.korean;
                        updateCount++;
                    }

                    const answerText = document.querySelectorAll('.accordion-body')[index];
                    if (answerText && faq.answer?.korean) {
                        answerText.textContent = faq.answer.korean;
                        updateCount++;
                    }
                });
            }
        }

        updateFooter(texts, updateCount);
        return updateCount;
    }

    // Update Contact Page
    function updateContactPage(texts, updateCount) {
        if (texts.contact_page) {
            // Hero section
            if (texts.contact_page.hero) {
                const subtitle = document.querySelector('.tp-contact-us-subtitle');
                if (subtitle && texts.contact_page.hero.subtitle?.korean) {
                    subtitle.textContent = texts.contact_page.hero.subtitle.korean;
                    updateCount++;
                }

                const titleSpans = document.querySelectorAll('.tp-contact-us-title span');
                if (titleSpans.length >= 2 && texts.contact_page.hero.title_part1?.korean && texts.contact_page.hero.title_part2?.korean) {
                    titleSpans[0].textContent = texts.contact_page.hero.title_part1.korean;
                    titleSpans[1].textContent = texts.contact_page.hero.title_part2.korean;
                    updateCount += 2;
                }

                const desc = document.querySelector('.tp-contact-us-wrapper p');
                if (desc && texts.contact_page.hero.description?.korean) {
                    desc.textContent = texts.contact_page.hero.description.korean;
                    updateCount++;
                }

                const scrollText = document.querySelector('.tp-contact-us-scroll-text p');
                if (scrollText && texts.contact_page.hero.scroll_text?.korean) {
                    scrollText.textContent = texts.contact_page.hero.scroll_text.korean;
                    updateCount++;
                }

                const mapText = document.querySelector('.tp-contact-us-scroll-map span');
                if (mapText && texts.contact_page.hero.map_text?.korean) {
                    mapText.textContent = texts.contact_page.hero.map_text.korean;
                    updateCount++;
                }
            }

            // Contact form
            if (texts.contact_page.form) {
                const formTitle = document.querySelector('.tp-contact-form-title');
                if (formTitle && texts.contact_page.form.title?.korean) {
                    formTitle.textContent = texts.contact_page.form.title.korean;
                    updateCount++;
                }

                // Form labels
                document.querySelectorAll('.tp-contact-form-field label').forEach(label => {
                    const text = label.textContent.trim();
                    if (texts.contact_page.form.name_label?.korean && text.includes('Full name')) {
                        label.textContent = texts.contact_page.form.name_label.korean;
                        updateCount++;
                    } else if (texts.contact_page.form.email_label?.korean && text.includes('Email address')) {
                        label.textContent = texts.contact_page.form.email_label.korean;
                        updateCount++;
                    } else if (texts.contact_page.form.website_label?.korean && text.includes('Website link')) {
                        label.textContent = texts.contact_page.form.website_label.korean;
                        updateCount++;
                    } else if (texts.contact_page.form.message_label?.korean && text.includes('How Can We Help You')) {
                        label.textContent = texts.contact_page.form.message_label.korean;
                        updateCount++;
                    }
                });

                const submitBtn = document.querySelector('.tp-btn-inner');
                if (submitBtn && texts.contact_page.form.submit_button?.korean) {
                    submitBtn.textContent = texts.contact_page.form.submit_button.korean;
                    updateCount++;
                }
            }

            // Location cards
            if (texts.contact_page.locations) {
                texts.contact_page.locations.forEach((location, index) => {
                    const locationName = document.querySelectorAll('.tp-contact-location-title')[index];
                    if (locationName && location.name?.korean) {
                        locationName.textContent = location.name.korean;
                        updateCount++;
                    }

                    const locationBtn = document.querySelectorAll('.tp-contact-location-btn')[index];
                    if (locationBtn && location.button_text?.korean) {
                        locationBtn.textContent = location.button_text.korean;
                        updateCount++;
                    }
                });
            }
        }

        updateFooter(texts, updateCount);
        return updateCount;
    }

    // Common footer update function
    function updateFooter(texts, updateCount) {
        // Footer main text
        if (texts.footer_section?.main_text?.korean) {
            const footerTitle = document.querySelector('.tp-footer-title-lg');
            if (footerTitle) {
                footerTitle.textContent = texts.footer_section.main_text.korean;
                updateCount++;
            }
        }

        // Quick links title
        if (texts.footer_section?.quick_links?.title?.korean) {
            const quickLinksTitle = document.querySelector('.tp-footer-widget h4.tp-footer-title');
            if (quickLinksTitle && quickLinksTitle.textContent.includes('Quick links')) {
                quickLinksTitle.textContent = texts.footer_section.quick_links.title.korean;
                updateCount++;
            }
        }

        // Quick links
        if (texts.footer_section?.quick_links?.links) {
            document.querySelectorAll('.tp-footer-list a').forEach(link => {
                const text = link.textContent.trim();
                texts.footer_section.quick_links.links.forEach(item => {
                    if (item.english === text && item.korean) {
                        link.textContent = item.korean;
                        updateCount++;
                    }
                });
            });
        }

        // Contact title
        if (texts.footer_section?.contact_info?.title?.korean) {
            const contactTitle = document.querySelectorAll('.tp-footer-widget h4.tp-footer-title')[1];
            if (contactTitle && contactTitle.textContent.includes('Contact')) {
                contactTitle.textContent = texts.footer_section.contact_info.title.korean;
                updateCount++;
            }
        }

        // Copyright
        if (texts.footer_section?.copyright?.text?.korean) {
            const copyrightText = document.querySelector('.tp-copyright-text');
            if (copyrightText) {
                copyrightText.innerHTML = texts.footer_section.copyright.text.korean;
                updateCount++;
            }
        }

        // Legal links
        if (texts.footer_section?.copyright?.links) {
            document.querySelectorAll('.tp-copyright-menu a').forEach(link => {
                const text = link.textContent.trim();
                texts.footer_section.copyright.links.forEach(item => {
                    if (item.english === text && item.korean) {
                        link.textContent = item.korean;
                        updateCount++;
                    }
                });
            });
        }
        return updateCount;
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', checkForUpdates);
    } else {
        checkForUpdates();
    }

})();